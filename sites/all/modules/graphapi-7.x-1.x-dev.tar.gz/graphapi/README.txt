
This is an API for rendering (Directed) Graphs onto the HTML5 canvas.

You could enable the graphapi_devel module to see it in action on the module page

This is a very course version missing a lot of features.
- graphapi.api.php
- more examples
- theme functions for node, user, comment
- ?

Please feel free to submit feature request and bug reports

