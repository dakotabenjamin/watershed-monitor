(function($) {

Drupal.visualization = Drupal.visualization || {};
Drupal.visualization.charts = Drupal.visualization.charts || {};

})(jQuery);
